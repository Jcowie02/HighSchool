guesses = [1,2,3,4]
del guesses[0]
print(guesses)
