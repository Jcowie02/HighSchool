file = open("test.txt", "x")
